# The Continental Blockade and European Price Networks

The project examines wheat and colonial commodity prices around the 1806 Berlin Decree. The main comparison uses 1798–1805, 1807–1814 and 1816–1823. The notebook follows data acquisition, validation, annual preprocessing, price-gap analysis, network construction and sensitivity evaluation.

The public Allen–Unger archive is available at [DataverseNL](https://doi.org/10.34894/IPVXMW). 
The four-market balanced wheat panel contains Southern England, Paris, Strasbourg and Arnhem. Sugar and pepper support England–Paris comparisons. Coffee supplies an English series. The report discusses the resulting geographical scope and the uncertainty of the historical interpretation.

## Sources and attribution

Bob Allen and Richard Unger, *The Allen Unger Commodities Dataset*, IISH Data Collection, version 1 (2018), current DataverseNL record [10.34894/IPVXMW](https://doi.org/10.34894/IPVXMW). The data carry [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). `DATA_LICENSE.md` records the attribution and transformations.

R. C. Allen and R. W. Unger (2019), “The Allen–Unger Global Commodity Prices Database,” [10.1163/24523666-00401006](https://doi.org/10.1163/24523666-00401006).
