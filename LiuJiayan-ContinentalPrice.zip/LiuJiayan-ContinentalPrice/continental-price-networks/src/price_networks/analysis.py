"""Validate annual silver prices and construct price-proximity networks."""
from __future__ import annotations

from itertools import combinations
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .download import read_csv_bytes, GRAIN_MARKETS

YEARS = range(1790, 1826)
PERIODS = {"Before": range(1798, 1806), "Blockade": range(1807, 1815),
           "After": range(1816, 1824)}
ENGLAND = "Southern England"


def prepare(root: Path) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Keep positive silver prices and fix variety and unit within each series."""
    frames = []
    for path in sorted((root / "data/raw").glob("*.csv")):
        if path.name in {"download_audit.csv", "cache_validation.csv"}:
            continue
        frame = read_csv_bytes(path.read_bytes())
        frame["source_file"] = path.name
        frames.append(frame)
    if not frames:
        raise ValueError("No commodity CSVs found")
    raw = pd.concat(frames, ignore_index=True)
    year = pd.to_numeric(raw["Year"], errors="coerce")
    price = pd.to_numeric(raw["Standardized Value"], errors="coerce")
    in_window = year.between(1790, 1825)
    valid_year = np.isfinite(year) & year.mod(1).eq(0)
    valid_price = np.isfinite(price) & price.gt(0)
    silver = raw["Standard Currency"].str.strip().str.casefold().eq("silver")
    unit = raw["Standard Measure"].isin(["Litre", "Kilogram"])
    valid = in_window & valid_year & valid_price & silver & unit
    clean = raw.loc[valid].copy()
    clean["Year"] = year[valid].astype(int)
    clean["price"] = price[valid].astype(float)
    clean["Variety"] = clean["Variety"].fillna("").str.strip()
    keys = ["Commodity", "Market", "Variety", "Standard Measure"]
    candidate_rows = []
    for key, group in clean.groupby(keys, dropna=False):
        observed = set(group.Year)
        counts = {name: len(observed.intersection(period)) for name, period in PERIODS.items()}
        candidate_rows.append(dict(zip(keys, key)) | counts | {
            "years": len(observed), "rows": len(group),
            "minimum_period_years": min(counts.values())})
    candidates = pd.DataFrame(candidate_rows)
    if candidates.empty:
        raise ValueError("No valid silver prices in 1790--1825")
    # Fix the series before examining price changes. Resolve ties lexically.
    selected = candidates.sort_values(
        ["Commodity", "Market", "minimum_period_years", "years", "Variety", "Standard Measure"],
        ascending=[True, True, False, False, True, True]
    ).drop_duplicates(["Commodity", "Market"])
    kept = clean.merge(selected[keys], on=keys, how="inner", validate="many_to_one")
    # Preserve raw source lines, while aggregating duplicate observations explicitly.
    annual = kept.groupby(keys + ["Year"], as_index=False).agg(
        price=("price", "median"), raw_observations=("price", "size"),
        source_count=("Sources", "nunique"))
    annual["log_price"] = np.log(annual.price)
    annual = annual.sort_values(["Commodity", "Market", "Year"]).reset_index(drop=True)
    quality = {
        "raw_rows": int(len(raw)), "window_rows": int(in_window.sum()),
        "valid_window_rows": int(valid.sum()),
        "invalid_window_rows": int((in_window & ~valid).sum()),
        "invalid_price_in_window": int((in_window & ~valid_price).sum()),
        "non_silver_in_window": int((in_window & ~silver).sum()),
        "unsupported_unit_in_window": int((in_window & ~unit).sum()),
        "alternative_series_rows_removed": int(len(clean) - len(kept)),
        "duplicate_annual_rows_aggregated": int(len(kept) - len(annual)),
        "annual_rows": int(len(annual)), "source_files": len(frames),
        "standardization": "Source-provided grams of silver per stated standard unit",
        "missing_year_policy": "No interpolation or forward filling"
    }
    target = root / "data/processed"
    target.mkdir(parents=True, exist_ok=True)
    annual.to_csv(target / "annual_prices.csv", index=False)
    candidates.to_csv(target / "series_candidates.csv", index=False)
    selected.to_csv(target / "series_coverage.csv", index=False)
    (target / "quality_summary.json").write_text(json.dumps(quality, indent=2), encoding="utf-8")
    return annual, selected, quality


def wheat_panel(annual: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    frame = annual.loc[annual.Commodity.eq("Wheat") & annual["Standard Measure"].eq("Litre")]
    panel = frame.pivot(index="Year", columns="Market", values="price").reindex(YEARS)
    # A fixed market set keeps the three principal period comparisons balanced.
    core = [m for m in GRAIN_MARKETS if m in panel and
            all(panel.loc[list(years), m].notna().all() for years in PERIODS.values())]
    if ENGLAND not in core or len(core) < 4:
        raise ValueError("Insufficient complete wheat series for the fixed market panel")
    return panel.loc[:, core], core


def pair_gaps(panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """The absolute log ratio is invariant to a common price-unit multiplier."""
    logs = np.log(panel)
    gaps = pd.DataFrame(index=panel.index)
    info = []
    for i, j in combinations(panel.columns, 2):
        pair = f"{i} | {j}"
        gaps[pair] = (logs[i] - logs[j]).abs()
        info.append({"pair": pair, "market_i": i, "market_j": j,
                     "group": "England--continent" if ENGLAND in (i, j) else "Continental"})
    return gaps, pd.DataFrame(info)


def component_count(markets: list[str], edges: pd.DataFrame) -> int:
    neighbours = {market: set() for market in markets}
    for row in edges.itertuples():
        neighbours[row.market_i].add(row.market_j)
        neighbours[row.market_j].add(row.market_i)
    unseen = set(markets)
    count = 0
    while unseen:
        count += 1
        stack = [unseen.pop()]
        while stack:
            current = stack.pop()
            new = neighbours[current] & unseen
            unseen -= new
            stack.extend(new)
    return count


def minimum_spanning_tree(edges: pd.DataFrame, markets: list[str]) -> pd.DataFrame:
    """Kruskal's algorithm retains n-1 links of minimum total price distance."""
    parent = {m: m for m in markets}

    def find(m: str) -> str:
        while parent[m] != m:
            parent[m] = parent[parent[m]]
            m = parent[m]
        return m

    chosen = []
    for idx, row in edges.sort_values(["gap", "pair"]).iterrows():
        a, b = find(row.market_i), find(row.market_j)
        if a != b:
            parent[a] = b
            chosen.append(idx)
        if len(chosen) == len(markets) - 1:
            break
    if len(chosen) != len(markets) - 1:
        raise ValueError("Pair graph is disconnected")
    return edges.loc[chosen].copy()


def period_analysis(panel: pd.DataFrame, ratio: float = 1.25) -> tuple[pd.DataFrame, pd.DataFrame]:
    gaps, info = pair_gaps(panel)
    summaries, edge_frames = [], []
    changes = np.log(panel).diff()  # Missing neighbouring years remain missing.
    for period, years in PERIODS.items():
        matrix = gaps.loc[list(years)]
        if matrix.isna().any().any():
            raise ValueError("Principal period matrix must be balanced")
        edges = info.copy()
        edges["gap"] = matrix.mean().reindex(edges.pair).to_numpy()
        edges["similarity"] = np.exp(-edges.gap)
        # Do not include a change crossing the boundary of a period.
        valid_changes = changes.loc[list(years)[1:]]
        edges["change_correlation"] = [valid_changes[i].corr(valid_changes[j])
                                       for i, j in zip(edges.market_i, edges.market_j)]
        edges["linked"] = edges.gap.le(np.log(ratio))
        tree = minimum_spanning_tree(edges, list(panel.columns))
        edges["in_mst"] = edges.index.isin(tree.index)
        edges["period"] = period
        for group in ("All", "England--continent", "Continental"):
            subset = edges if group == "All" else edges.loc[edges.group.eq(group)]
            summaries.append({"period": period, "group": group, "pairs": len(subset),
                "mean_gap": subset.gap.mean(), "geometric_ratio": np.exp(subset.gap.mean()),
                "edge_density": subset.linked.mean(),
                "mean_change_correlation": subset.change_correlation.mean(),
                "components": component_count(list(panel.columns), edges.loc[edges.linked]) if group == "All" else np.nan})
        edge_frames.append(edges)
    return pd.DataFrame(summaries), pd.concat(edge_frames, ignore_index=True)


def block_resample(array: np.ndarray, rng: np.random.Generator, block: int = 2) -> np.ndarray:
    """Circular two-year blocks retain short sequences and joint pair dependence."""
    n = len(array)
    starts = rng.integers(0, n, size=int(np.ceil(n / block)))
    idx = np.concatenate([(start + np.arange(block)) % n for start in starts])[:n]
    return array[idx]


def uncertainty(panel: pd.DataFrame, repetitions: int = 2000, seed: int = 42) -> pd.DataFrame:
    gaps, info = pair_gaps(panel)
    before = gaps.loc[list(PERIODS["Before"])].to_numpy()
    during = gaps.loc[list(PERIODS["Blockade"])].to_numpy()
    if not np.isfinite(before).all() or not np.isfinite(during).all():
        raise ValueError("Bootstrap requires a complete pair-year matrix")
    mask = info.group.eq("England--continent").to_numpy()

    def statistics(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        delta = b.mean(axis=0) - a.mean(axis=0)
        return np.array([delta.mean(), delta[mask].mean(), delta[~mask].mean(),
                         delta[mask].mean() - delta[~mask].mean()])

    point = statistics(before, during)
    rng = np.random.default_rng(seed)
    samples = np.array([statistics(block_resample(before, rng), block_resample(during, rng))
                        for _ in range(repetitions)])
    lo, hi = np.quantile(samples, [0.025, 0.975], axis=0)
    return pd.DataFrame({"comparison": ["All pairs", "England--continent", "Continental",
                                        "Difference between groups"],
                         "change": point, "lower": lo, "upper": hi,
                         "bootstrap_repetitions": repetitions, "block_years": 2})


def robustness(panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    gaps, info = pair_gaps(panel)
    rows = []
    for ratio in (1.10, 1.15, 1.20, 1.25, 1.30, 1.40, 1.50):
        summary, _ = period_analysis(panel, ratio)
        for row in summary.itertuples():
            rows.append({"ratio_threshold": ratio, "period": row.period,
                         "group": row.group, "edge_density": row.edge_density,
                         "components": row.components})
    dates = []
    for anchor in (1798, 1802, 1806, 1810, 1814):
        pre, post = range(anchor - 8, anchor), range(anchor + 1, anchor + 9)
        # Use only markets complete in BOTH windows for each date. Report composition.
        use = [m for m in panel if panel.loc[list(pre) + list(post), m].notna().all()]
        if ENGLAND not in use or len(use) < 4:
            continue
        local_gaps, local_info = pair_gaps(panel[use])
        delta = local_gaps.loc[list(post)].mean() - local_gaps.loc[list(pre)].mean()
        eng = local_info.loc[local_info.group.eq("England--continent"), "pair"]
        con = local_info.loc[local_info.group.eq("Continental"), "pair"]
        dates.append({"anchor_year": anchor, "markets": len(use), "pairs": len(local_info),
                      "england_change": delta[eng].mean(), "continental_change": delta[con].mean(),
                      "difference_between_groups": delta[eng].mean() - delta[con].mean()})
    leaves = []
    for excluded in [m for m in panel if m != ENGLAND]:
        small = panel.drop(columns=excluded)
        result = uncertainty(small, repetitions=200, seed=42)
        leaves.append({"excluded_market": excluded,
                       "difference_between_groups": result.iloc[-1]["change"]})
    return pd.DataFrame(rows), pd.DataFrame(dates), pd.DataFrame(leaves)


def colonial_comparisons(annual: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Normalize each colonial series by its own pre-decree geometric mean."""
    colonial = annual.loc[annual.Commodity.isin(["Sugar", "Coffee", "Pepper"])].copy()
    indices, coverage = [], []
    for (commodity, market), group in colonial.groupby(["Commodity", "Market"]):
        pre = group.loc[group.Year.isin(PERIODS["Before"])]
        during = group.loc[group.Year.isin(PERIODS["Blockade"])]
        post = group.loc[group.Year.isin(PERIODS["After"])]
        coverage.append({"commodity": commodity, "market": market, "unit": group["Standard Measure"].iloc[0],
                         "years": group.Year.nunique(), "before_years": pre.Year.nunique(),
                         "blockade_years": during.Year.nunique(), "after_years": post.Year.nunique()})
        if len(pre) >= 6:
            base = np.exp(np.log(pre.price).mean())
            row = group.copy()
            row["index"] = 100 * row.price / base
            indices.append(row)
    indexed = pd.concat(indices, ignore_index=True) if indices else pd.DataFrame()
    pairs = []
    for commodity, group in colonial.groupby("Commodity"):
        for i, j in combinations(sorted(group.Market.unique()), 2):
            a, b = group.loc[group.Market.eq(i)], group.loc[group.Market.eq(j)]
            if a["Standard Measure"].iloc[0] != b["Standard Measure"].iloc[0]:
                continue
            joined = a[["Year", "price"]].merge(b[["Year", "price"]], on="Year", suffixes=("_i", "_j"))
            joined["gap"] = np.abs(np.log(joined.price_i / joined.price_j))
            before = joined.loc[joined.Year.isin(PERIODS["Before"])]
            during = joined.loc[joined.Year.isin(PERIODS["Blockade"])]
            after = joined.loc[joined.Year.isin(PERIODS["After"])]
            # Sparse colonial records use common observed years within each pair.
            if min(len(before), len(during)) >= 6:
                pairs.append({"commodity": commodity, "market_i": i, "market_j": j,
                              "unit": a["Standard Measure"].iloc[0], "Before": before.gap.mean(),
                              "Blockade": during.gap.mean(), "After": after.gap.mean(),
                              "before_years": len(before), "blockade_years": len(during),
                              "after_years": len(after),
                              "change": during.gap.mean() - before.gap.mean()})
    return indexed, pd.DataFrame(coverage), pd.DataFrame(pairs)


def save_tables(root: Path, **tables: pd.DataFrame) -> None:
    target = root / "outputs/tables"
    target.mkdir(parents=True, exist_ok=True)
    for name, table in tables.items():
        table.to_csv(target / f"{name}.csv", index=False)


def colonial_shared_years(annual: pd.DataFrame) -> pd.DataFrame:
    """Compare sugar and pepper using identical England--Paris calendar years."""
    series = {}
    for commodity in ("Sugar", "Pepper"):
        for market in ("England", "Paris"):
            rows = annual.loc[annual.Commodity.eq(commodity) & annual.Market.eq(market)
                              & annual["Standard Measure"].eq("Kilogram")]
            series[(commodity, market)] = rows.set_index("Year").price
    common = set.intersection(*(set(s.index) for s in series.values()))
    rows = []
    for commodity in ("Sugar", "Pepper"):
        gap = np.log(series[(commodity, "England")] / series[(commodity, "Paris")]).abs()
        record = {"commodity": commodity}
        for period, years in PERIODS.items():
            observed = sorted(common.intersection(years))
            if len(observed) < 4:
                raise ValueError("Insufficient common colonial observations")
            record[period] = gap.loc[observed].mean()
            record[f"{period}_years"] = len(observed)
        record["change"] = record["Blockade"] - record["Before"]
        rows.append(record)
    return pd.DataFrame(rows)


def run_analysis(root: Path) -> dict:
    annual, coverage, quality = prepare(root)
    panel, core = wheat_panel(annual)
    summary, edges = period_analysis(panel)
    intervals = uncertainty(panel)
    thresholds, dates, leaves = robustness(panel)
    indexed, colonial_coverage, colonial_pairs = colonial_comparisons(annual)
    shared_years = colonial_shared_years(annual)
    gaps, pair_info = pair_gaps(panel)
    annual_gap = pd.DataFrame({group: gaps.loc[:, pair_info.loc[pair_info.group.eq(group), "pair"]].mean(axis=1)
                              for group in pair_info.group.unique()})
    annual_gap.index.name = "Year"
    # Counts expose any changes in yearly coverage outside the balanced comparison windows.
    annual_gap["observed_markets"] = panel.notna().sum(axis=1)
    annual_gap["observed_pairs"] = gaps.notna().sum(axis=1)
    annual_gap.loc[annual_gap.observed_markets.lt(len(core)), list(pair_info.group.unique())] = np.nan
    save_tables(root, period_summary=summary, pair_edges=edges, bootstrap_intervals=intervals,
                threshold_sensitivity=thresholds, alternative_dates=dates, leave_one_out=leaves,
                colonial_coverage=colonial_coverage, colonial_pairs=colonial_pairs,
                colonial_shared_years=shared_years,
                colonial_indices=indexed, annual_gap=annual_gap.reset_index(),
                wheat_prices=panel.reset_index())
    result = {"annual": annual, "coverage": coverage, "quality": quality, "panel": panel,
              "core": core, "summary": summary, "edges": edges, "intervals": intervals,
              "thresholds": thresholds, "dates": dates, "leaves": leaves, "indexed": indexed,
              "colonial_coverage": colonial_coverage, "colonial_pairs": colonial_pairs,
              "shared_years": shared_years,
              "annual_gap": annual_gap}
    (root / "outputs/tables/analysis_manifest.json").write_text(json.dumps({
        "core_markets": core, "periods": {k: list(v) for k, v in PERIODS.items()},
        "threshold_ratio": 1.25, "bootstrap_seed": 42, "bootstrap_repetitions": 2000,
        "data_quality": quality}, indent=2), encoding="utf-8")
    return result
