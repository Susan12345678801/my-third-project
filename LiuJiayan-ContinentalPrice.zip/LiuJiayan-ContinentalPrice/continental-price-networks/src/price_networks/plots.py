"""Figures used in both the notebook and the research report."""
from __future__ import annotations

from itertools import combinations
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd

from .analysis import YEARS, PERIODS, ENGLAND

BLUE, ORANGE, GREEN, PURPLE = "#28668c", "#cd7134", "#388572", "#8b609f"
COLORS = [BLUE, ORANGE, GREEN, PURPLE]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "semibold", "figure.dpi": 130,
                     "savefig.dpi": 220})


def _save(fig, root: Path, name: str):
    target = root / "outputs/figures"
    target.mkdir(parents=True, exist_ok=True)
    fig.savefig(target / f"{name}.png", bbox_inches="tight", facecolor="white")
    fig.savefig(target / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    return fig


def _shade(ax):
    ax.axvspan(1806.5, 1814.5, color=ORANGE, alpha=0.08)
    ax.axvline(1806, color="#777777", linestyle=":", linewidth=1)
    ax.set_xlim(1790, 1825)
    ax.set_xticks([1790, 1800, 1806, 1815, 1825])
    ax.grid(axis="y", alpha=0.16)


def coverage_figure(annual: pd.DataFrame, coverage: pd.DataFrame, root: Path):
    wheat = coverage.loc[coverage.Commodity.eq("Wheat")].sort_values(
        ["minimum_period_years", "Market"], ascending=[False, True])
    colonial = coverage.loc[~coverage.Commodity.eq("Wheat")].sort_values(["Commodity", "Market"])
    fig, axes = plt.subplots(1, 2, figsize=(11.6, 5.8), gridspec_kw={"width_ratios": [1, 1]})
    for ax, rows, title in zip(axes, [wheat, colonial], ["Wheat series", "Colonial commodity series"]):
        matrix, labels = [], []
        for row in rows.itertuples():
            ys = set(annual.loc[annual.Commodity.eq(row.Commodity) & annual.Market.eq(row.Market), "Year"])
            matrix.append([int(year in ys) for year in YEARS])
            labels.append(row.Market if row.Commodity == "Wheat" else f"{row.Commodity}: {row.Market}")
        ax.imshow(matrix, aspect="auto", interpolation="none", cmap=ListedColormap(["#edf0f2", BLUE]), vmin=0, vmax=1)
        ax.set_yticks(range(len(labels)), labels, fontsize=9)
        ax.set_xticks([0, 10, 16, 25, 35], [1790, 1800, 1806, 1815, 1825])
        ax.axvline(16, color=ORANGE, linewidth=1.1)
        ax.set_title(title)
        ax.set_xlabel("Year")
    fig.legend(handles=[Patch(facecolor=BLUE, label="Observed silver price"),
                        Patch(facecolor="#edf0f2", label="Missing year")],
               loc="lower center", ncol=2, frameon=False, bbox_to_anchor=(0.5, -0.015))
    fig.tight_layout(w_pad=2.5)
    return _save(fig, root, "coverage")


def price_figure(panel: pd.DataFrame, annual_gap: pd.DataFrame, root: Path):
    fig, axes = plt.subplots(1, 2, figsize=(11.3, 3.6))
    for color, market in zip(COLORS, panel):
        axes[0].plot(panel.index, panel[market], color=color, label=market, linewidth=1.5)
    axes[0].set_ylabel("Grams of silver per litre")
    axes[0].set_title("Wheat prices")
    axes[0].legend(frameon=False, fontsize=8.3, ncol=2)
    for column, color in [("England--continent", ORANGE), ("Continental", BLUE)]:
        axes[1].plot(annual_gap.index, annual_gap[column], label=column, color=color, linewidth=1.7)
    axes[1].set_ylabel("Mean absolute log price ratio")
    axes[1].set_title("Annual price separation")
    axes[1].legend(frameon=False, fontsize=9)
    for ax in axes:
        _shade(ax)
        ax.set_xlabel("Year")
    fig.tight_layout(w_pad=2)
    return _save(fig, root, "wheat_prices_and_gaps")


def network_figure(edges: pd.DataFrame, core: list[str], root: Path):
    positions = {ENGLAND: (-0.85, 0.75), "Arnhem": (0.85, 0.75),
                 "Paris": (-0.85, -0.65), "Strasbourg": (0.85, -0.65)}
    if set(core) != set(positions):
        angles = np.linspace(0, 2 * np.pi, len(core), endpoint=False)
        positions = {m: (np.cos(t), np.sin(t)) for m, t in zip(core, angles)}
    fig, axes = plt.subplots(1, 3, figsize=(11.6, 3.6))
    for ax, period in zip(axes, PERIODS):
        local = edges.loc[edges.period.eq(period)]
        for row in local.itertuples():
            x1, y1 = positions[row.market_i]
            x2, y2 = positions[row.market_j]
            color = BLUE if row.linked else "#a0a6aa"
            style = "-" if row.linked else "--" if row.in_mst else ":"
            ax.plot([x1, x2], [y1, y2], color=color, linestyle=style,
                    linewidth=2.6 if row.linked else 1.5 if row.in_mst else 0.6,
                    alpha=1 if row.in_mst or row.linked else 0.4, zorder=1)
            if row.in_mst:
                ax.text((x1+x2)/2, (y1+y2)/2, f"{row.gap:.2f}", ha="center", va="center",
                        fontsize=9, bbox=dict(facecolor="white", edgecolor="none", pad=1.5), zorder=3)
        for market, (x, y) in positions.items():
            ax.scatter(x, y, s=340, color=ORANGE if market == ENGLAND else BLUE,
                       edgecolor="white", linewidth=1.3, zorder=4)
            label = "S. England" if market == ENGLAND else market
            ax.text(x, y + (0.24 if y > 0 else -0.27), label, ha="center", fontsize=9.5)
        years = list(PERIODS[period])
        ax.set_title(f"{period}: {years[0]}--{years[-1]}")
        ax.set_xlim(-1.3, 1.3)
        ax.set_ylim(-1.25, 1.25)
        ax.axis("off")
    fig.legend(handles=[Line2D([0], [0], color=BLUE, lw=2.6, label="Gap at most log(1.25)"),
                        Line2D([0], [0], color="#a0a6aa", lw=1.5, ls="--", label="Other spanning-tree link")],
               loc="lower center", frameon=False, ncol=2, bbox_to_anchor=(0.5, -0.025))
    fig.tight_layout()
    return _save(fig, root, "price_networks")


def pair_figure(edges: pd.DataFrame, root: Path):
    before = edges.loc[edges.period.eq("Before")].set_index("pair")
    during = edges.loc[edges.period.eq("Blockade")].set_index("pair").reindex(before.index)
    labels = [f"{i.replace(ENGLAND, 'S. England')} / {j.replace(ENGLAND, 'S. England')}"
              for i, j in zip(before.market_i, before.market_j)]
    colors = [ORANGE if g == "England--continent" else BLUE for g in before.group]
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 3.8))
    y = np.arange(len(before))
    axes[0].barh(y, during.gap.to_numpy() - before.gap.to_numpy(), color=colors, height=0.6)
    axes[0].axvline(0, color="#666666", lw=0.8)
    axes[0].set_yticks(y, labels, fontsize=8.8)
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Change in mean absolute log ratio")
    axes[0].set_title("Wheat gap changes")
    for idx, color in enumerate(colors):
        axes[1].plot([before.iloc[idx].change_correlation, during.iloc[idx].change_correlation],
                     [idx, idx], color=color, linewidth=1.7)
    axes[1].scatter(before.change_correlation, y, color=colors, marker="o", label="Before", zorder=3)
    axes[1].scatter(during.change_correlation, y, color=colors, marker="s", label="Blockade", zorder=3)
    axes[1].set_yticks(y, [])
    axes[1].invert_yaxis()
    axes[1].set_xlim(-1.05, 1.05)
    axes[1].set_xlabel("Correlation of annual log price changes")
    axes[1].set_title("Price co-movement")
    axes[1].legend(frameon=False, fontsize=9)
    for ax in axes:
        ax.grid(axis="x", alpha=0.15)
    fig.tight_layout(w_pad=2.2)
    return _save(fig, root, "pair_changes")


def colonial_figure(indexed: pd.DataFrame, annual: pd.DataFrame, root: Path):
    fig, axes = plt.subplots(1, 2, figsize=(11.3, 3.9))
    commodity_colors = {"Wheat": BLUE, "Sugar": ORANGE, "Pepper": GREEN, "Coffee": PURPLE}
    for ax, market in zip(axes, ["England", "Paris"]):
        selected = indexed.loc[indexed.Market.eq(market)]
        for commodity, group in selected.groupby("Commodity"):
            series = group.set_index("Year")["index"].reindex(YEARS)
            ax.plot(series.index, series, label=commodity, color=commodity_colors[commodity], lw=1.7,
                    marker=".", markersize=3)
        wheat_market = ENGLAND if market == "England" else "Paris"
        wheat = annual.loc[annual.Commodity.eq("Wheat") & annual.Market.eq(wheat_market)].copy()
        base = np.exp(np.log(wheat.loc[wheat.Year.isin(PERIODS["Before"]), "price"]).mean())
        # Reindex to leave gaps visible.
        wheat_line = (100 * wheat.set_index("Year").price / base).reindex(YEARS)
        ax.plot(wheat_line.index, wheat_line, label="Wheat (S. England)" if market == "England" else "Wheat",
                color=BLUE, lw=1.6, ls="--")
        ax.axhline(100, color="#999999", lw=0.7)
        _shade(ax)
        ax.set_title("English series" if market == "England" else "Paris")
        ax.set_xlabel("Year")
        ax.set_ylabel("Index: pre-decree geometric mean = 100")
        ax.legend(frameon=False, fontsize=8.5, ncol=2)
    fig.tight_layout(w_pad=2)
    return _save(fig, root, "colonial_price_indices")


def robustness_figure(thresholds: pd.DataFrame, dates: pd.DataFrame, root: Path):
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 3.6))
    for period, color in zip(PERIODS, [BLUE, ORANGE, GREEN]):
        subset = thresholds.loc[thresholds.period.eq(period) & thresholds.group.eq("All")]
        axes[0].plot(subset.ratio_threshold, subset.edge_density, color=color, marker="o", label=period)
    axes[0].axvline(1.25, color="#888888", lw=0.8, ls=":")
    axes[0].set_xlabel("Price-ratio threshold")
    axes[0].set_ylabel("Share of six wheat pairs linked")
    axes[0].set_ylim(-0.03, 1.03)
    axes[0].set_title("Threshold sensitivity")
    axes[0].legend(frameon=False, fontsize=9)
    axes[1].bar(dates.anchor_year, dates.difference_between_groups,
                color=[ORANGE if y == 1806 else BLUE for y in dates.anchor_year], width=2)
    axes[1].axhline(0, color="#777777", lw=0.8)
    axes[1].set_xticks(dates.anchor_year)
    axes[1].set_xlabel("Comparison anchor year")
    axes[1].set_ylabel("England change minus continental change")
    axes[1].set_title("Alternative eight-year comparisons")
    for ax in axes:
        ax.grid(axis="y", alpha=0.15)
    fig.tight_layout(w_pad=2.5)
    return _save(fig, root, "robustness")


def make_figures(result: dict, root: Path) -> None:
    figures = [coverage_figure(result["annual"], result["coverage"], root),
               price_figure(result["panel"], result["annual_gap"], root),
               network_figure(result["edges"], result["core"], root),
               pair_figure(result["edges"], root),
               colonial_figure(result["indexed"], result["annual"], root),
               robustness_figure(result["thresholds"], result["dates"], root)]
    for fig in figures:
        plt.close(fig)
