"""Download public Allen--Unger CSVs, verify checksums and reject HTML pages."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha1, sha256
from io import BytesIO
import json
from pathlib import Path
import time

import pandas as pd
import requests

BASE = "https://dataverse.nl"
PID = "doi:10.34894/IPVXMW"
METADATA_URL = f"{BASE}/api/datasets/:persistentId/?persistentId={PID}"
GRAIN_MARKETS = ["Southern England", "Amsterdam", "Paris", "Strasbourg",
                 "Leipzig", "Munich", "Vienna", "Pisa", "Warsaw", "Stockholm",
                 "Utrecht", "Arnhem", "Toulouse", "Wurzburg", "Florence", "Siena",
                 "Danzig", "Barcelona"]
COLONIAL_MARKETS = ["England", "Andalusia", "Antwerp", "Augsburg", "Barcelona",
                   "Florence", "Frankfurt", "Ghent", "Leon", "Milan", "Modena",
                   "New Castile", "Paris", "Sopron", "Valencia", "Vienna",
                   "Wallachia", "Wroclaw"]
REQUIRED_COLUMNS = ["Commodity", "Variety", "Market", "Original Measure",
                    "Standard Measure", "Original Currency", "Standard Currency",
                    "Year", "Original Value", "Standardized Value", "Notes", "Sources"]


def read_csv_bytes(content: bytes) -> pd.DataFrame:
    """The archive contains both UTF-8 and Latin-1 source encodings."""
    if content.lstrip().lower().startswith((b"<!doctype", b"<html", b"<?xml")):
        raise ValueError("Received a web page instead of commodity data")
    for encoding in ("utf-8-sig", "latin-1"):
        try:
            frame = pd.read_csv(BytesIO(content), encoding=encoding)
            break
        except UnicodeDecodeError:
            continue
    if list(frame.columns) != REQUIRED_COLUMNS:
        raise ValueError(f"Unexpected CSV schema: {list(frame.columns)}")
    if frame.empty:
        raise ValueError("Empty commodity file")
    return frame


def _get(url: str) -> requests.Response:
    error = None
    for attempt in range(3):
        try:
            response = requests.get(url, timeout=(15, 60))
            response.raise_for_status()
            return response
        except requests.RequestException as exc:
            error = exc
            if attempt < 2:
                time.sleep(1 + attempt)
    raise RuntimeError(f"Download failed: {url}") from error


def acquire(root: Path, refresh: bool = False) -> pd.DataFrame:
    """Fetch metadata and selected files, or validate the bundled source cache."""
    raw = root / "data" / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    metadata_path = raw / "dataset_metadata.json"
    if refresh or not metadata_path.exists():
        response = _get(METADATA_URL)
        metadata = response.json()
        if metadata.get("status") != "OK":
            raise ValueError("Dataset metadata request did not return OK")
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    files = metadata["data"]["latestVersion"]["files"]
    wanted = {f"{market}_Wheat.csv" for market in GRAIN_MARKETS}
    wanted |= {f"{market}_{commodity}.csv" for market in COLONIAL_MARKETS
               for commodity in ("Sugar", "Coffee", "Pepper")}
    selected = [f["dataFile"] for f in files if f["dataFile"]["filename"] in wanted]
    present = {f["filename"] for f in selected}
    missing_grain = {f"{m}_Wheat.csv" for m in GRAIN_MARKETS} - present
    if missing_grain:
        raise ValueError(f"Required wheat files absent: {missing_grain}")

    def fetch(file: dict) -> dict:
        path = raw / file["filename"]
        url = f"{BASE}/api/access/datafile/{file['id']}"
        downloaded = refresh or not path.exists()
        if downloaded:
            response = _get(url)
            content = response.content
        else:
            content = path.read_bytes()
        expected = file["checksum"]
        if expected["type"] != "SHA-1" or sha1(content).hexdigest() != expected["value"]:
            raise ValueError(f"Archive checksum mismatch: {path.name}")
        frame = read_csv_bytes(content)
        if downloaded:
            temporary = path.with_suffix(".tmp")
            temporary.write_bytes(content)
            temporary.replace(path)
        return {"filename": path.name, "file_id": file["id"], "url": url,
                "http_status": response.status_code if downloaded else None,
                "content_type": response.headers.get("Content-Type") if downloaded else None,
                "bytes": len(content), "rows": len(frame),
                "sha256": sha256(content).hexdigest(), "archive_sha1_verified": True,
                "mode": "download" if downloaded else "validated_cache",
                "checked_at_utc": datetime.now(timezone.utc).isoformat()}

    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(fetch, selected))
    result = pd.DataFrame(records).sort_values("filename").reset_index(drop=True)
    # Keep the actual HTTP evidence when a later run validates the cache.
    result.to_csv(raw / "cache_validation.csv", index=False)
    downloads = result.loc[result["mode"].eq("download")]
    if not downloads.empty:
        audit_path = raw / "download_audit.csv"
        old = pd.read_csv(audit_path) if audit_path.exists() else pd.DataFrame()
        audit = pd.concat([old, downloads], ignore_index=True)
        audit.drop_duplicates("filename", keep="last").to_csv(audit_path, index=False)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    audit = acquire(root, refresh=args.refresh)
    print(audit[["filename", "rows", "bytes", "mode"]].to_string(index=False))


if __name__ == "__main__":
    main()
